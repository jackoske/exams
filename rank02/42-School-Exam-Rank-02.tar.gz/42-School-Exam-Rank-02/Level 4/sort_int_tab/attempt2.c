#include <stdio.h>
#include <stdlib.h>

void sort_int_tab(int *tab, unsigned int size){
    int i = 0;
    int temp;
    while (i < size-1){
        if (tab[i] > tab[i+1])
        {
            temp = tab[i];
            tab[i]=tab[i+1];
            tab[i+1]= temp;
            i = 0;
        }else
            i++;
    }
}

// void sort_int_tab(int *tab, unsigned int size) {
//     unsigned int i = 0, j;
//     int temp;
//     while (i < size - 1) {
//         j = 0;
//         while (j < size - 1 - i) {
//             if (tab[j] > tab[j + 1]) {
//                 temp = tab[j];
//                 tab[j] = tab[j + 1];
//                 tab[j + 1] = temp;
//             }
//             j++;
//         }
//         i++;
//     }
// }
int main() {
    int array[] = {30, 10, 20, 20, 50, 20, 40};
    unsigned int size = sizeof(array) / sizeof(array[0]);

    // Call the sorting function
    sort_int_tab(array, size);

    // Print the sorted array
    printf("Sorted Array: ");
    for (unsigned int i = 0; i < size; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    return 0;
}