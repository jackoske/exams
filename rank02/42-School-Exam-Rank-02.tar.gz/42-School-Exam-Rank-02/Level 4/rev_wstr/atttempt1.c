# include <unistd.h>

static int ft_strlen(char *str)
{
    int i = 0;

    while(str[i])
        i++;
    return (i);
} 
static void ft_putchar(char c)
{
    write(1, &c, 1);
} 

static void ft_putstr_space(char *str)
{
    while(*str != '\0' && *str != ' ')
    {
        ft_putchar(*str);
        str++;
    }
}

int main(int argc, char **argv)
{
    int length;

    if (argc == 2)
    {
        length = ft_strlen(argv[1]);
        while (length)
        {
            if(argv[1][length]== ' ')
            {
                ft_putstr_space(&(argv[1][length+1]));
                write(1, " ", 1);
            }
            length--;
        }
        ft_putstr_space(&(argv[1][length+1]));

        

    }
    else
        write(1, "\n", 1);
}