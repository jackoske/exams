#include <stdio.h>
#include <stdlib.h>

int     *ft_rrange(int start, int end){
    int *range;
    int size;
    
    size = ((start > end) ?  start - end :  end - start)+1;
    range = (int *)malloc(size * sizeof(int));
    if (!range)
        return (NULL);
    while (--size >= 0)
        range[size] = (start > end) ? start-- : start++;
    return (range);
}

int main(){
    int *arr;
    arr = ft_rrange(0, -3);
    printf("%d, %d, %d", arr[0], arr[1], arr[2]);
    free(arr);
    return 0;
}