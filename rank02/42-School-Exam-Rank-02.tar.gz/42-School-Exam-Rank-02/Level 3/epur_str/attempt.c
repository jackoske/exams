#include <unistd.h>

void ft_putchar(char c) {
    write(1, &c, 1);
}


void epur_str(char *str) {
    int i = 0;
    int word_printed = 0;

    // Skip leading spaces/tabs
    while (str[i] == ' ' || str[i] == '\t')
        i++;

    // Process the string
    while (str[i]) {
        // If the current character is not a space/tab, print it
        if (str[i] != ' ' && str[i] != '\t') {
            ft_putchar(str[i]);
            word_printed = 1;
        }
        // If it is a space/tab, check for the next non-space/tab character
        else if (word_printed && (str[i + 1] != ' ' && str[i + 1] != '\t' && str[i + 1] != '\0')) {
            ft_putchar(' ');
            word_printed = 0;
        }
        i++;
    }
}


int main(int argc, char **argv) {
    if (argc == 2)
        epur_str(argv[1]);
    ft_putchar('\n');
    return 0;
}