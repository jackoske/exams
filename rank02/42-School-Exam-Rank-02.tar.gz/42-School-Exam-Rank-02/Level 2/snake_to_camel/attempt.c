#include <unistd.h>

int main(int argc, char **argv)
{
	int i = 0;
	
	if (argc ==2 )
	{
		while(argv[1][i] != '\0')
		{
			if (argv[1][i] == '_')
			{
				i++;
				argv[1][i] = argv[1][i]-32;
			}
			write (1, &argv[1][i], 1);
			i++;
		}
	}
	write(1, "\n", 1);
}

// #include <stdio.h>
// #include <stdlib.h>
// #include <ctype.h> // for toupper function

// int main(int argc, char **argv) {
//     if (argc != 2) {
//         fprintf(stderr, "Usage: %s snake_case_string\n", argv[0]);
//         return 1;
//     }

//     char *ptr = argv[1];
//     int i = 0, j = 0;
//     int len = 0;

//     // Calculate the length of the new string
//     while (ptr[i]) {
//         if (ptr[i] != '_') {
//             len++;
//         }
//         i++;
//     }

//     char *camelCaseStr = malloc((len + 1) * sizeof(char)); // +1 for the null terminator
//     if (camelCaseStr == NULL) {
//         perror("Failed to allocate memory");
//         return 1;
//     }

//     i = 0;
//     while (ptr[i]) {
//         if (ptr[i] == '_' && ptr[i + 1] != '\0') {
//             i++;
//             camelCaseStr[j++] = toupper(ptr[i]);
//         } else {
//             camelCaseStr[j++] = ptr[i];
//         }
//         i++;
//     }
//     camelCaseStr[j] = '\0'; // Null terminate the new string

//     printf("%s\n", camelCaseStr);
//     free(camelCaseStr); // Free the allocated memory
//     return 0;
// }