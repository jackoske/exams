unsigned char	reverse_bits(unsigned char octet)
{
	int		i = 8;
	unsigned char	res = 0;

	while (i > 0)
	{
		res = res * 2 + (octet % 2);
		octet = octet / 2;
		i--;
	}
	return (res);
}

// unsigned char reverse_bits(unsigned char octet) {
//     unsigned char res = 0;
//     int i = 8;

//     while (i > 0) {
//         res <<= 1;             // Shift res to the left by 1 bit
//         res |= (octet & 1);    // Copy the least significant bit of octet to res
//         octet >>= 1;           // Shift octet to the right by 1 bit
//         i--;
//     }

//     return res;
// }
// unsigned char reverse(unsigned char b) {
//    b = (b & 0xF0) >> 4 | (b & 0x0F) << 4;
//    b = (b & 0xCC) >> 2 | (b & 0x33) << 2;
//    b = (b & 0xAA) >> 1 | (b & 0x55) << 1;
//    return b;
// }